#!/usr/bin/env python3
"""Read-only Bybit Spot historical backtest for Sekerinskiy Trader v0.1.

Never reads secrets; never sends orders. Signal rules track trader.py v0.1;
execution approximates spread, slippage, taker fees and is NOT proof of live fills.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Optional

# Import the exact indicator implementations and signal constants from v0.1.
import trader

SYMBOLS = ('XRPUSDT', 'SOLUSDT', 'DOGEUSDT')
STEP_MS = 300_000
DAY_MS = 86_400_000
INITIAL_CASH = Decimal('3.13959928')


def dec(v):
    return Decimal(str(v))


def iso(t_ms):
    return datetime.fromtimestamp(t_ms / 1000, tz=timezone.utc).strftime('%Y-%m-%d %H:%M UTC')


@dataclass(frozen=True)
class Candle:
    t: int
    o: Decimal
    h: Decimal
    l: Decimal
    c: Decimal
    v: Decimal


def fetch_candles(session, symbol: str, start_ms: int, end_exclusive_ms: int):
    """Download inclusive start ... exclusive end; reject missing or invalid bars."""
    end_cursor = end_exclusive_ms - 1
    acc = {}
    requests_made = 0
    while end_cursor >= start_ms:
        data = session.get_kline(category='spot', symbol=symbol, interval='5',
                                 start=start_ms, end=end_cursor, limit=1000)
        if data.get('retCode') != 0:
            raise RuntimeError(f'{symbol}: Bybit error {data.get("retCode")} {data.get("retMsg")}')
        rows = data.get('result', {}).get('list', [])
        requests_made += 1
        if not rows:
            raise RuntimeError(f'{symbol}: API returned no data before {iso(end_cursor)}')
        previous_oldest = end_cursor
        for row in rows:
            t = int(row[0])
            if t < start_ms or t >= end_exclusive_ms:
                continue
            c = Candle(t, dec(row[1]), dec(row[2]), dec(row[3]), dec(row[4]), dec(row[5]))
            if (t % STEP_MS != 0 or c.l <= 0 or c.o <= 0 or c.h < c.l or
                    min(c.o, c.c) < c.l or max(c.o, c.c) > c.h or c.v < 0):
                raise RuntimeError(f'{symbol}: invalid candle at {t}')
            acc[t] = c
        oldest = min(int(row[0]) for row in rows)
        if oldest > previous_oldest:
            raise RuntimeError(f'{symbol}: historical pagination did not advance')
        end_cursor = oldest - 1
        if oldest <= start_ms:
            break
        if requests_made > 100:
            raise RuntimeError(f'{symbol}: too many history requests')
        time.sleep(0.15)
    expected = range(start_ms, end_exclusive_ms, STEP_MS)
    missing = [t for t in expected if t not in acc]
    if missing:
        raise RuntimeError(f'{symbol}: missing {len(missing)} of {len(expected)} candles; '
                           f'first missing: {iso(missing[0])}; backtest aborted to avoid bias')
    print(f'  {symbol}: {len(acc)} candles, {requests_made} API calls')
    return acc


def signal_from_bars(bars, current_open=None, spread_bps=5, slippage_bps=3):
    """Calculate v0.1 signal from <=120 CLOSED candles; optional next open check."""
    if len(bars) < 55:
        return False
    bars = bars[-120:]
    closes = [b.c for b in bars]
    volumes = [b.v for b in bars]
    ema9 = trader.ema(closes, 9)[-1]
    ema21 = trader.ema(closes, 21)[-1]
    strength = trader.rsi(closes)
    vol_avg = sum(volumes[-21:-1]) / Decimal(20)
    if vol_avg == 0:
        return False
    valid = (ema9 > ema21 and closes[-1] > ema9 and closes[-1] > closes[-2]
             and Decimal(50) <= strength <= Decimal(65)
             and volumes[-1] >= vol_avg * trader.MIN_VOL_MULTIPLIER
             and closes[-1] / closes[-2] - 1 < Decimal('0.015'))
    # Historical best bid/ask snapshots are not available in public OHLCV.
    assumed_spread = Decimal(spread_bps) / 10000
    valid = valid and assumed_spread <= trader.MAX_SPREAD
    if current_open is not None:
        assumed_ask = current_open * (1 + assumed_spread / 2)
        valid = valid and abs(assumed_ask / closes[-1] - 1) <= trader.MAX_SINCE_CLOSE
    return bool(valid)


def estimate_sell(raw_price, spread_bps, slippage_bps):
    cost = (Decimal(spread_bps) / Decimal(20000)
            + Decimal(slippage_bps) / Decimal(10000))
    return raw_price * (1 - cost)


def estimate_buy(raw_price, spread_bps, slippage_bps):
    cost = (Decimal(spread_bps) / Decimal(20000)
            + Decimal(slippage_bps) / Decimal(10000))
    return raw_price * (1 + cost)


def simulation(data, start_ms, end_ms, fee, spread_bps, slippage_bps, mode):
    cash = INITIAL_CASH
    position = None
    pending = None
    closed_trades = []
    peak = INITIAL_CASH
    max_dd = Decimal(0)
    day = None
    day_start_equity = INITIAL_CASH
    loss_streak = 0
    last_action_t = -10**18
    equity_points = []
    histories = {s: deque(maxlen=120) for s in SYMBOLS}
    warmup_start = start_ms - DAY_MS
    for t in range(warmup_start, end_ms, STEP_MS):
        # append historical bars as they close; only after bar open/position handling
        current = {s: data[s][t] for s in SYMBOLS}
        if t < start_ms:
            for s in SYMBOLS:
                histories[s].append(current[s])
            continue

        def marked_equity(use_open=False):
            value = cash
            if position:
                bar = current[position['symbol']]
                price = bar.o if use_open else bar.c
                value += position['qty'] * estimate_sell(price, spread_bps, slippage_bps) * (1-fee)
            return value

        utc_day = datetime.fromtimestamp(t/1000, timezone.utc).date()
        if utc_day != day:
            day = utc_day
            day_start_equity = marked_equity(use_open=True)
            loss_streak = 0

        if pending is not None and position is None:
            symbol = pending
            bar = current[symbol]
            # Signal was recorded at PREVIOUS closed candle, not today's close.
            prior = list(histories[symbol])
            buy = estimate_buy(bar.o, spread_bps, slippage_bps)
            if (signal_from_bars(prior, bar.o, spread_bps, slippage_bps)
                    and marked_equity(use_open=True) > day_start_equity * Decimal('0.98')
                    and loss_streak < 3
                    and t - last_action_t >= 1_800_000):
                spent = cash * Decimal('0.90')
                qty = spent / (buy * (1+fee))
                cash -= spent
                position = {'symbol': symbol, 'entry': buy, 'cost': spent,
                            'qty': qty, 'entry_t': t}
                last_action_t = t
            pending = None

        if position:
            symbol = position['symbol']
            bar = current[symbol]
            entry = position['entry']
            target = entry * (1 + trader.TP)
            stop = entry * (1 - trader.SL)
            exit_price = None
            reason = None
            if mode == 'close':
                bid_close = estimate_sell(bar.c, spread_bps, slippage_bps)
                if bid_close <= stop:
                    reason, exit_price = 'SL at close', bid_close
                elif bid_close >= target:
                    reason, exit_price = 'TP at close', bid_close
            else:
                # Conservative ambiguous-bar handling: a stop is assumed first.
                low_bid = bar.l * (1-Decimal(spread_bps)/Decimal(20000))
                high_bid = bar.h * (1-Decimal(spread_bps)/Decimal(20000))
                open_bid = bar.o * (1-Decimal(spread_bps)/Decimal(20000))
                if low_bid <= stop:
                    reason = 'SL intrabar'
                    exit_price = min(stop, open_bid) * (1-Decimal(slippage_bps)/Decimal(10000))
                elif high_bid >= target:
                    reason = 'TP intrabar'
                    exit_price = target * (1-Decimal(slippage_bps)/Decimal(10000))
            if exit_price is not None:
                proceeds = position['qty'] * exit_price * (1-fee)
                pnl = proceeds - position['cost']
                cash += proceeds
                closed_trades.append({
                    'symbol': symbol, 'buy_time_utc': iso(position['entry_t']),
                    'sell_time_utc': iso(t), 'entry_price': str(position['entry']),
                    'exit_price': str(exit_price), 'pnl_usdt': str(pnl),
                    'result_pct_on_cost': str(pnl/position['cost']*100), 'exit_reason': reason
                })
                loss_streak = (loss_streak+1) if pnl < 0 else 0
                last_action_t = t
                position = None

        eq = marked_equity()
        peak = max(peak, eq)
        max_dd = max(max_dd, (peak-eq)/peak)
        equity_points.append((t, eq))

        # At time t+STEP_MS, only OHLCV for candle t (now CLOSED) may be used.
        for s in SYMBOLS:
            histories[s].append(current[s])
        if (position is None and pending is None
                and t - last_action_t + STEP_MS >= 1_800_000
                and eq > day_start_equity*Decimal('0.98')
                and loss_streak < 3):
            for s in SYMBOLS:
                if signal_from_bars(list(histories[s]), None, spread_bps, slippage_bps):
                    pending = s
                    break

    last_c = {s: data[s][end_ms-STEP_MS] for s in SYMBOLS}
    final_equity = cash
    if position:
        final_equity += position['qty'] * estimate_sell(last_c[position['symbol']].c,
                                                      spread_bps, slippage_bps) * (1-fee)
    wins = sum(1 for x in closed_trades if dec(x['pnl_usdt']) > 0)
    gross_profit = sum((dec(x['pnl_usdt']) for x in closed_trades if dec(x['pnl_usdt']) > 0), Decimal(0))
    gross_loss = -sum((dec(x['pnl_usdt']) for x in closed_trades if dec(x['pnl_usdt']) < 0), Decimal(0))
    realized = sum((dec(x['pnl_usdt']) for x in closed_trades), Decimal(0))
    return {
        'mode': mode, 'period_start_utc': iso(start_ms), 'period_end_utc': iso(end_ms),
        'starting_usdt': str(INITIAL_CASH), 'ending_equity_usdt': str(final_equity),
        'cash_usdt': str(cash), 'open_position': position and position['symbol'],
        'return_pct': round(float((final_equity/INITIAL_CASH-1)*100), 4),
        'max_drawdown_pct': round(float(max_dd*100), 4),
        'closed_trades': len(closed_trades), 'wins': wins,
        'win_rate_pct': round(100*wins/len(closed_trades), 2) if closed_trades else None,
        'realized_pnl_usdt': str(realized),
        'profit_factor': round(float(gross_profit/gross_loss), 4) if gross_loss else (None if not wins else 'inf'),
        'trades': closed_trades,
    }


def main():
    parser = argparse.ArgumentParser(description='Safe Bybit historical spot backtest (NO ORDER APIs)')
    parser.add_argument('--days', type=int, default=30, help='Historical evaluation window, default 30')
    parser.add_argument('--fee', type=str, default='0.001', help='Assumed fee per trade side, default 0.001=0.1%%')
    parser.add_argument('--spread-bps', type=int, default=5, help='Assumed FULL spread in basis points, default 5 = 0.05%%')
    parser.add_argument('--slippage-bps', type=int, default=3, help='Assumed slippage EACH SIDE in bp, default 3 = 0.03%%')
    parser.add_argument('--outdir', type=str, default='backtest_reports')
    args = parser.parse_args()
    if not (1 <= args.days <= 90):
        parser.error('--days must be between 1 and 90')
    fee = dec(args.fee)
    if not (0 <= fee <= Decimal('0.01')):
        parser.error('--fee outside expected range [0, 0.01]')
    if not (0 <= args.spread_bps <= 15 and 0 <= args.slippage_bps <= 50):
        parser.error('invalid spread/slippage')
    # Import HTTP only for public market candles; NO credentials and NO secrets.
    from pybit.unified_trading import HTTP
    end_ms = (int(time.time()*1000) // STEP_MS)*STEP_MS
    start_ms = end_ms - args.days*DAY_MS
    warmup_ms = start_ms - DAY_MS
    api = HTTP(testnet=False)
    print('READ-ONLY HISTORICAL TEST. Does not read API keys or place orders.')
    print(f'Period: {iso(start_ms)} to {iso(end_ms)} (exclusive), plus 1-day warmup')
    data = {}
    for symbol in SYMBOLS:
        data[symbol] = fetch_candles(api, symbol, warmup_ms, end_ms)
    results = [simulation(data, start_ms, end_ms, fee, args.spread_bps,
                          args.slippage_bps, mode) for mode in ('close', 'intrabar')]
    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True, mode=0o700)
    outdir.chmod(0o700)
    with (outdir/'summary.json').open('w') as f:
        json.dump([{k:v for k,v in x.items() if k!='trades'} for x in results], f, indent=2, ensure_ascii=False)
    with (outdir/'trades.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['mode','symbol','buy_time_utc','sell_time_utc',
                                                'entry_price','exit_price','pnl_usdt',
                                                'result_pct_on_cost','exit_reason'])
        writer.writeheader()
        for x in results:
            for row in x['trades']:
                writer.writerow({'mode':x['mode'], **row})
    for x in results:
        print('\n' + '='*54)
        print('Exit model:', x['mode'])
        print('Completed trades:', x['closed_trades'], '| Wins:', x['wins'],
              '| Win rate:', x['win_rate_pct'], '%')
        print('Start:', x['starting_usdt'], 'USDT | End:', x['ending_equity_usdt'], 'USDT')
        print('Return:', f'{x["return_pct"]:+.4f}%', '| Max drawdown:',
              f'{x["max_drawdown_pct"]:.4f}%', '| Profit factor:', x['profit_factor'])
        print('Realized P&L:', x['realized_pnl_usdt'], 'USDT; Open:', x['open_position'])
    print('\nSaved:', outdir/'summary.json', 'and', outdir/'trades.csv')
    print('ASSUMPTIONS: fixed spread/slippage, 0.1% fee default; no book history or partial fills.')
    print('This models paper trading only; no real order meets the 5 USDT Spot minimum with 3.1396 USDT.')


if __name__ == '__main__':
    main()
