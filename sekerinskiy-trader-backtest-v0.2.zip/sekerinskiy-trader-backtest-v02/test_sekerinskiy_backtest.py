"""Offline unit checks; no Bybit access required."""
import sys
import types
import unittest
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

# Let trader.py import safely even when pybit is not installed in local CI.
try:
    from pybit.unified_trading import HTTP
except ImportError:
    pybit = types.ModuleType('pybit')
    unified_trading = types.ModuleType('pybit.unified_trading')
    unified_trading.HTTP = object
    pybit.unified_trading = unified_trading
    sys.modules['pybit'] = pybit
    sys.modules['pybit.unified_trading'] = unified_trading

import trader
from importlib.machinery import SourceFileLoader
backtest = SourceFileLoader('backtest', str(Path(__file__).with_name('backtest.py'))).load_module()

class TestBacktest(unittest.TestCase):
    def setUp(self):
        self.start = 2_000_000_000_000 // backtest.STEP_MS * backtest.STEP_MS
        self.end = self.start + backtest.DAY_MS
        self.data = {}
        for s in backtest.SYMBOLS:
            bars = {}
            for i,t in enumerate(range(self.start-backtest.DAY_MS,self.end,backtest.STEP_MS)):
                price = Decimal('1')
                bars[t] = backtest.Candle(t,price,price,price,price,Decimal('100'))
            self.data[s] = bars

    def test_flat_series_no_entries(self):
        for mode in ('close', 'intrabar'):
            r = backtest.simulation(self.data, self.start, self.end, Decimal('.001'),5,3,mode)
            self.assertEqual(r['closed_trades'],0)
            self.assertIsNone(r['open_position'])
            self.assertEqual(Decimal(r['ending_equity_usdt']),backtest.INITIAL_CASH)

    def test_no_lookahead_before_completed_candle(self):
        # Override signal so it fires on a specific closed candle but not before.
        trigger = self.start + backtest.STEP_MS*2
        def fake_signal(bars, current_open=None, spread_bps=5, slippage_bps=3):
            return bars[-1].t == trigger
        with patch.object(backtest, 'signal_from_bars', side_effect=fake_signal):
            r = backtest.simulation(self.data, self.start, self.end,Decimal('.001'),5,3,'close')
        self.assertEqual(r['open_position'],'XRPUSDT')
        self.assertLess(Decimal(r['ending_equity_usdt']),backtest.INITIAL_CASH)


    def test_api_pagination_complete(self):
        # Mock historical API in reverse order (Bybit v5 format, 1000 rows/page).
        start = self.start - backtest.DAY_MS
        end = self.end
        all_bars = self.data['DOGEUSDT']
        class FakeHTTP:
            def get_kline(self, **kwargs):
                xs = [all_bars[t] for t in sorted(all_bars, reverse=True)
                      if kwargs['start'] <= t <= kwargs['end']][:kwargs['limit']]
                return {'retCode': 0, 'result': {'list': [
                    [str(x.t), str(x.o), str(x.h), str(x.l), str(x.c), str(x.v)] for x in xs]}}
        with patch.object(backtest.time, 'sleep', return_value=None):
            actual = backtest.fetch_candles(FakeHTTP(), 'DOGEUSDT', start, end)
        self.assertEqual(len(actual), len(all_bars))
        self.assertEqual(min(actual), start)
        self.assertEqual(max(actual), end-backtest.STEP_MS)

    def test_simulated_sell_is_never_live_trade(self):
        # One signal on a finished candle, entry next candle; large later move triggers paper TP.
        signal_at = self.start + 2*backtest.STEP_MS
        exit_t = signal_at + 3*backtest.STEP_MS
        bar = self.data['XRPUSDT'][exit_t]
        self.data['XRPUSDT'][exit_t] = backtest.Candle(exit_t, bar.o, Decimal('1.06'), bar.l,
                                                       Decimal('1.06'), bar.v)
        def fake_signal(bars, current_open=None, spread_bps=5, slippage_bps=3):
            return bars[-1].t == signal_at
        with patch.object(backtest, 'signal_from_bars', side_effect=fake_signal):
            out = backtest.simulation(self.data, self.start, self.end, Decimal('0.001'), 5, 3, 'close')
        self.assertEqual(out['closed_trades'], 1)
        self.assertEqual(out['wins'], 1)
        self.assertEqual(out['trades'][0]['buy_time_utc'], backtest.iso(signal_at+backtest.STEP_MS))
        self.assertEqual(out['trades'][0]['sell_time_utc'], backtest.iso(exit_t))

    def test_spread_slippage_reduce_proceeds(self):
        gross = backtest.estimate_buy(Decimal('100'),5,3)
        bid = backtest.estimate_sell(Decimal('100'),5,3)
        self.assertGreater(gross,Decimal('100'))
        self.assertLess(bid,Decimal('100'))
        self.assertLess(bid/gross, Decimal('1'))

if __name__ == '__main__':
    unittest.main()
